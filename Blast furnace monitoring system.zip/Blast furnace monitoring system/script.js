const tempFurnace1 = document.getElementById('temp-furnace1');
const tempFurnace2 = document.getElementById('temp-furnace2');
const tempFurnace3 = document.getElementById('temp-furnace3');

// Update temperature readings every 5 seconds
setInterval(() => {
	// Simulate temperature readings from API
	const temp1 = Math.floor(Math.random() * (1000 - 500 + 1) + 500);
	const temp2 = Math.floor(Math.random() * (1000 - 500 + 1) + 500);
	const temp3 = Math.floor(Math.random() * (1000 - 500 + 1) + 500);

	tempFurnace1.textContent = temp1;
	tempFurnace2.textContent = temp2;
	tempFurnace3.textContent = temp3;
}, 5000);
